import tensorflow as tf
from tensorflow.keras import layers
from tensorflow import keras
from keras.layers import Dropout
import random
from keras.regularizers import l2
from keras.layers import Concatenate # Add this line
from tensorflow.keras.layers import Input


keras.utils.set_random_seed(20)

# If using TensorFlow, this will make GPU ops as deterministic as possible,
# but it will affect the overall performance, so be mindful of that.
tf.config.experimental.enable_op_determinism()

def build_model(output_units: int, input_shape: tuple, feature_input_shape: int):

    model = keras.Sequential()

    model.add(layers.Conv2D(filters=64, kernel_size=(3, 3), activation='relu', input_shape=input_shape))
    model.add(layers.AveragePooling2D())
    model.add(layers.Dropout(0.2, seed=20))
    model.add(layers.Conv2D(filters=128, kernel_size=(3, 3), activation='relu'))
    model.add(layers.AveragePooling2D())
    model.add(layers.Dropout(0.2, seed=20))
    model.add(layers.Conv2D(filters=256, kernel_size=(3, 3), activation='relu'))
    model.add(layers.AveragePooling2D())
    model.add(layers.Dropout(0.2, seed=20))
    model.add(layers.Flatten())


    model.add(layers.Dense(units=512, activation='relu'))
    model.add(layers.Dense(units=256, activation='relu'))


    nuc_input = keras.layers.Input(shape=(feature_input_shape,), name='nucleus_input')
    merged = Concatenate()([model.output, nuc_input])
    merged1= layers.Dense(units=64, activation='relu')(merged)
    
    merged2=layers.Dense(units=16, activation='relu')(merged1)
    
    model_output = layers.Dense(units=output_units, activation='linear')(merged2)

    model = keras.Model(inputs=[model.input, nuc_input], outputs=model_output)
    return model
