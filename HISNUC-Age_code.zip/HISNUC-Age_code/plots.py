
import numpy as np
import pandas as pd
import seaborn as sns
import scipy.stats as stats
from matplotlib import pyplot as plt
from statsmodels.stats.multitest import multipletests
from sklearn.metrics import median_absolute_error
def plot_loss(history, current_path):
    plt.figure(figsize=(8.5, 8))
    plt.style.use("classic")
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.title('model loss')
    plt.ylabel('mae')
    plt.xlabel('epoch')
    plt.legend(['train', 'val'], loc='upper left')
    plt.savefig(current_path / "mae_validation_loss.png", bbox_inches="tight")
    plt.show()

def plot_log_loss(history, current_path):
    plt.figure(figsize=(8.5, 8))
    plt.style.use("classic")
    plt.plot(np.log(history.history['loss']))
    plt.plot(np.log(history.history['val_loss']))
    plt.title('model loss')
    plt.ylabel('mae')
    plt.xlabel('epoch')
    plt.legend(['train', 'val'], loc='upper left')
    plt.savefig(current_path / "mae_validation_loss-log.png",bbox_inches="tight")
    plt.show()
    
    
def aggregate_value(y_pred, test_label, Image_ID):
    
    value_to_indices = {}
    for i, value in enumerate(Image_ID):
        if value not in value_to_indices:
            value_to_indices[value] = [i]
        else:
            value_to_indices[value].append(i)

    # Initialize an empty array to store the grouped data
    grouped_array_label = np.empty((len(value_to_indices), 1))
    grouped_array_pred = np.empty((len(value_to_indices), 1))

    # Calculate means and populate the grouped array
    for i, value in enumerate(value_to_indices.keys()):
        indices = value_to_indices[value]
        grouped_row_label = np.mean(test_label[indices], axis=0)
        grouped_row_pred = np.mean(y_pred[indices], axis=0)
        grouped_array_label[i] = grouped_row_label
        grouped_array_pred[i] = grouped_row_pred
    
    return grouped_array_pred, grouped_array_label


def calculate_correlation(y_pred_wsi, test_label_wsi):
    corr=[]
    corr_df=pd.DataFrame(np.nan, index=range(1), columns=range(1))
    p_df=pd.DataFrame(np.nan, index=range(1), columns=range(1))
    mae_df = pd.DataFrame(np.nan, index=range(1), columns=range(2))
    for i in range(1):

        j=i
        a=stats.pearsonr(y_pred_wsi[:,j], test_label_wsi[:,i])#spearmanr, axis=0, nan_policy='propagate', alternative='two-sided')  

        a=list(a)
        corr=a[0]
        corr_df.iloc[i,0]=corr
        p=a[1]
        p_df.iloc[i,0]=p
        
        
        mae = median_absolute_error(y_pred_wsi[:,i], test_label_wsi[:,i])
        mae_df.iloc[i,0] = mae
        mean_age_label = np.mean(test_label_wsi[:,i])
        mae_df.iloc[i,1]=mean_age_label

    final_corr005=pd.DataFrame(np.nan, index=range(1), columns=range(1))
    final_corr005["corr_p_005"]=corr_df[p_df<0.05]
    final_corr005["index"]=range(1)
    final_corr005["raw_corr"]=corr_df
    final_corr005["raw_p"]=p_df
    multi=multipletests(np.array(final_corr005["raw_p"]) , alpha=0.05, method='hs', is_sorted=False, returnsorted=False)

    final_corr005["multi"]=multi[1]
    final_corr005['corr_multi_005'] = final_corr005['corr_p_005'].where(final_corr005['multi'] < 0.05)
    final_corr005.to_excel("aging_prediction_corr_005_genes.xlsx")
    mae_df.to_excel("aging_prediction_mae_genes.xlsx")

    return final_corr005["corr_multi_005"], multi, mae

def plot_corr_distribution(data, current_path):
    data=data[~np.isnan(data)]
    fig = plt.figure(figsize =(2, 6))
    plt.style.use("fast")
    plt.boxplot(data)
    plt.ylim(0,1.0)
    plt.tick_params(labelsize=14)
    plt.savefig(current_path / "correlation-distribution.png",bbox_inches="tight")
    plt.show()
    return None

def plot_scatter(y_pred, test_label, mae):

    y_pred_wsi=[]
    test_label_wsi=[]
    for i in range(len(test_label)-1):
        n=[]
        m=[]
        n.append(y_pred[i])
        m.append(test_label[i])

        if test_label[i]!=test_label[i+1]:
            #print(test_label[i])
            y_pred_wsi.append(np.median(np.array(n)))
            test_label_wsi.append(np.median(np.array(m)))
            n=[]
            m=[]

    # Plot the two arrays as a scatter plot
    plt.scatter(test_label_wsi, y_pred_wsi, c='blue', label='Scatter Plot')
    plt.xlabel('label')
    plt.ylabel('pred')
    plt.title('Scatter Plot of Two Arrays')
    plt.legend()
    plt.grid(True)
    corr,p=stats.pearsonr(np.array(y_pred_wsi).reshape(-1), np.array(test_label_wsi).reshape(-1))   
    plt.text(0.03, 0.85, f'Pearson Correlation: {corr:.2f}', fontsize=12, transform=plt.gca().transAxes)
    plt.text(0.03, 0.8, f'P value: {p:.2e}', fontsize=12, transform=plt.gca().transAxes)
    plt.text(0.03, 0.7, f'mae: {mae:.2e}', fontsize=12, transform=plt.gca().transAxes)


    plt.savefig('scatter_plot_WSI.png')
    np.save("y_pred_wsi.npy", y_pred_wsi)
    np.save("test_label_wsi.npy", test_label_wsi)
    
    return None




def all_plots(history, y_pred, test_label, Image_ID_test, current_path):

    plot_loss(history, current_path)
    plot_log_loss(history, current_path)

    y_pred_wsi, test_label_wsi=aggregate_value(y_pred, test_label, Image_ID_test)
    data, multi, mae = calculate_correlation(y_pred_wsi, test_label_wsi)
    plot_corr_distribution(data, current_path)

    np.save("y_pred_wsi.npy",y_pred_wsi)
    np.save("test_label_wsi.npy",test_label_wsi)
    
    plot_scatter(y_pred_wsi, test_label_wsi, mae)


    return None
