
import os
import random
import numpy as np
import pandas as pd
from augumentation import selection
from logger_config import logger
def is_valid_patch(arr):
    return arr.shape[0] == 32 and arr.shape[1] == 32 and arr.shape[2] == 128 and np.isnan(arr[:,:,1]).sum() < 450 #32

def augment_patch(arr,nucleus_label, y, sum_x, sum_nucleus, sum_y, i, Image_ID,occup, is_train_data):
    if is_valid_patch(arr):
        arr1 = np.nan_to_num(arr)
        sum_x.append(arr1)
        sum_nucleus.append(nucleus_label)
        sum_y.append(y)
        Image_ID.append(i)
        occup.append(np.isnan(arr[:,:,1]).sum()/(32*32))


def process_slide(i, nucleus_label, y_label, sum_x ,sum_nucleus, sum_y, Image_ID, occup, is_train_data):
    a = np.load(i + "_features.npy")
    b = np.swapaxes(a, 0, 2)
    unit_list = []
    
    for j in range(128):
        c = b[:,:,j][~np.isnan(b[:,:,j]).all(axis=1)]
        d = (c.T[~np.isnan(c.T).all(axis=1)]).T
        unit_list.append(d)
        
    e = np.array(unit_list)
    f = np.swapaxes(e, 0, 2)
    
    f_len = f.shape[0]
    f_width = f.shape[1]
    f_len_int = f_len // 16
    f_width_int = f_width // 16
    
    for k in range(f_len_int - 2):
        for p in range(f_width_int - 2):
            patch100 = f[k * 16:(k * 16 + 32), p * 16:(p * 16 + 32),:]
            augment_patch(patch100,nucleus_label, y_label, sum_x, sum_nucleus, sum_y, i, Image_ID, occup, is_train_data)
        
 
        patch100 = f[k * 16:(k * 16 + 32), -33:-1,:]
        augment_patch(patch100,nucleus_label, y_label, sum_x, sum_nucleus, sum_y, i, Image_ID, occup, is_train_data)

    for p in range(f_width_int-2):
        patch100 = f[-33:-1,p * 16:(p * 16 + 32),:]
        augment_patch(patch100,nucleus_label, y_label, sum_x, sum_nucleus, sum_y, i, Image_ID, occup, is_train_data)

    patch100 = f[-33:-1,-33:-1,:]
    augment_patch(patch100,nucleus_label, y_label, sum_x, sum_nucleus, sum_y, i, Image_ID, occup, is_train_data)
    


def process_all_slides(data, nucleus, labels, is_train_data, image_dir):
    sum_x = []
    sum_nucleus=[]
    sum_y = []
    Image_ID=[]
    occup=[]

    os.chdir(image_dir)
    if is_train_data:
        logger.info("Processing all slides: training")
    else:
        logger.info("Processing all slides: testing")
        

    for index, i in enumerate(data.iterrows()):

        y_label = labels.iloc[index] # access label using integer index
        image_file = data.iloc[index]['image_file']
        nucleus_label= nucleus.iloc[index]
        process_slide(image_file, nucleus_label, y_label, sum_x, sum_nucleus, sum_y, Image_ID, occup, is_train_data)

    logger.info("Finished processing.")
    return sum_x, sum_nucleus, sum_y, Image_ID, occup



def stack_data(sum_x,sum_nucleus, sum_y, Image_ID, occup):
  
    image = np.stack(sum_x)
    nucleus=np.stack(sum_nucleus)
    label = np.array(sum_y).reshape(-1)
    occup = np.array(occup)
    Image_ID=np.array(Image_ID)
    
    
    image_dic = {i: image[i] for i in range(len(Image_ID))}
    nucleus_dic= {i: nucleus[i] for i in range(len(Image_ID))}
    # Create a DataFrame for images
    image_df = pd.DataFrame({"Label": label, "Image_ID": Image_ID, "Occupancy": occup})

    # Sort the DataFrame by Image_ID and Occupancy
    image_df.sort_values(by=["Image_ID", "Occupancy"], ascending=[True, False], inplace=True)

    # Group by Image_ID and select the top two images with the highest occupancy
    top_images = image_df.groupby("Image_ID").head(8)


    values_list = [image_dic[key] for key in top_images.index]
    nucleus_list= [nucleus_dic[key] for key in top_images.index]
    x=np.stack(values_list)
    nuc=np.stack(nucleus_list)#.reshape(-1, 5)
    print(nuc.shape)
    y=np.array(top_images["Label"]).reshape(-1, 1)
    Image_ID_sum=top_images["Image_ID"]
    Occup=np.array(top_images["Occupancy"])
    return x, nuc, y, Image_ID_sum, Occup
