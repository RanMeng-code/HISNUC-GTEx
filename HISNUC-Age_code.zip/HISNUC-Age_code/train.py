
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import tensorflow as tf
from tensorflow.keras import optimizers, losses
import data_setup, processingslide
import experiment_setup
import model_builder, save_models, plots
from tensorflow.keras import layers
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
from matplotlib import pyplot as plt
import argparse
from logger_config import setup_logger, logger
import numpy as np

parser = argparse.ArgumentParser(description='Training script')
parser.add_argument('--target', type=int, default=1)
parser.add_argument('--seed', type=int, default=20)
parser.add_argument('--test_size', type=float, default=0.33)
parser.add_argument('--image_count', type=int, default=100)
parser.add_argument('--learning_rate', type=float, default=0.00005)
parser.add_argument('--batch_size', type=int, default=10)
parser.add_argument('--epochs', type=int, default=5)
parser.add_argument('--csv_file',type=str, default='path_to_expression_file_this_only_for_filter_out_image_file')
parser.add_argument('--image_dir', type=str, default="path_to_output_directery")
parser.add_argument('--qupath_feature_path', type=str, default="path_to_qupath-feature.csv")
parser.add_argument('--metadata_file', type=str, default="/gpfs/gibbs/pi/gerstein/rm2586/GTEx-imaging-prediction/GTEx-meta-032724.csv")
parser.add_argument('--nuc_feature', nargs='+', default=[], help="List of nucleus features")



args = parser.parse_args()

if args.image_count > 800:
    logger.info("Error: image_count cannot be more than 800")
    exit()

current_path = experiment_setup.initialize_experiment(args)
setup_logger(current_path)
logger.info(tf.__version__)
logger.info(tf.config.list_physical_devices('GPU'))
logger.info('Experiment setup complete.')

train_data, nucleus_train, train_tag, val_data, nucleus_val, val_tag, test_data, nucleus_test, test_tag= data_setup.create_datasets(
    args.csv_file,
    args.qupath_feature_path,
    args.metadata_file,
    args.image_dir,
    args.nuc_feature,
    current_path,
    target=args.target, 
    seed=args.seed,
    image_count=args.image_count,
    test_size=args.test_size
)



logger.info("################whole_sample_size")
logger.info(nucleus_train.shape)
logger.info(nucleus_val.shape)
logger.info(nucleus_test.shape)

sum_x_train, sum_nucleus_train, sum_y_train, Image_ID_train, occup_train = processingslide.process_all_slides(train_data, nucleus_train, train_tag, True, args.image_dir)
sum_x_val, sum_nucleus_val, sum_y_val, Image_ID_val, occup_val = processingslide.process_all_slides(val_data, nucleus_val, val_tag, False, args.image_dir)
sum_x_test, sum_nucleus_test, sum_y_test, Image_ID_test, occup_test = processingslide.process_all_slides(test_data, nucleus_test, test_tag, False, args.image_dir)


logger.info("####################processing_slide")

train_image, train_nucleus, train_labels, Image_ID_train_final, occup_train_final = processingslide.stack_data(sum_x_train, sum_nucleus_train, sum_y_train, Image_ID_train, occup_train)
val_image, val_nucleus, val_labels, Image_ID_val_final, occup_val_final= processingslide.stack_data(sum_x_val, sum_nucleus_val, sum_y_val, Image_ID_val, occup_val)
test_image, test_nucleus, test_labels, Image_ID_test_final, occup_test_final = processingslide.stack_data(sum_x_test, sum_nucleus_test, sum_y_test, Image_ID_test, occup_test)

logger.info("################sample_size")
logger.info(train_image.shape)
logger.info(train_nucleus.shape)
logger.info(test_image.shape)
logger.info("Processing all slides: training 64*64, smaller than 1800, top4, without amplification, shift 32, decay_steps=2000, decay_rate=0.9")

logger.info("###################whole_sample_size_inuse_before_stacking")
logger.info(len(set(Image_ID_train)))
logger.info(len(set(Image_ID_val)))
logger.info(len(set(Image_ID_test)))


logger.info("###################whole_sample_size_inuse_after_stacking")
logger.info(len(set(Image_ID_train_final)))
logger.info(len(set(Image_ID_val_final)))
logger.info(len(set(Image_ID_test_final)))


logger.info(f"\ntrain_image_shape: {train_image.shape}")
input_shape = train_image.shape[1:]
output_units = train_labels.shape[1]
feature_input_shape = train_nucleus.shape[1]
logger.info(f"\nnucleus_input: {feature_input_shape}")

model = model_builder.build_model(output_units, input_shape, feature_input_shape)
logger.info("model summary")
logger.info(model.summary())
os.chdir(current_path)

lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
    args.learning_rate,
    decay_steps=10000,
    decay_rate=0.95,
    staircase=True)


callbacks = [
    ModelCheckpoint(
        filepath="noise_mnist.keras",
        save_best_only=True,
        monitor="val_loss"),
    EarlyStopping(monitor='val_loss', patience=30)
]


opt = tf.keras.optimizers.SGD(learning_rate=lr_schedule)
model.compile(optimizer=opt, loss="mse")


history = model.fit([train_image, train_nucleus], train_labels, epochs=args.epochs, batch_size=args.batch_size, validation_data=([val_image,val_nucleus], val_labels), callbacks=callbacks)
y_pred = model.predict([test_image,test_nucleus])
results = model.evaluate([test_image,test_nucleus], test_labels)


save_models.save_model(model=model,
           history=history,
           current_path=current_path,
           target_dir="models",
           model_name="basic.h5",
           y_pred=y_pred,
           test_label=test_labels)

logger.info("Making plots")
plots.all_plots(history, y_pred, test_labels, Image_ID_test_final, current_path)
logger.info("Done.")


