import tensorflow as tf
from tensorflow.keras import layers
from tensorflow import keras
from keras.layers import Dropout
import random
from keras.regularizers import l2
from keras.layers import Concatenate # Add this line
from tensorflow.keras.layers import Input

keras.utils.set_random_seed(20)

# If using TensorFlow, this will make GPU ops as deterministic as possible,
# but it will affect the overall performance, so be mindful of that.
tf.config.experimental.enable_op_determinism()

def build_model(output_units: int, input_shape: tuple, nucleus_input):
    model = keras.Sequential()

    model.add(layers.Conv2D(filters=64, kernel_size=(3, 3), activation='relu', input_shape=input_shape))
    model.add(layers.AveragePooling2D())
    model.add(layers.Dropout(0.2, seed=20))
    model.add(layers.Conv2D(filters=128, kernel_size=(3, 3), activation='relu'))
    model.add(layers.AveragePooling2D())
    model.add(layers.Dropout(0.2, seed=20))
    model.add(layers.Conv2D(filters=256, kernel_size=(3, 3), activation='relu'))
    model.add(layers.AveragePooling2D())
    model.add(layers.Dropout(0.2, seed=20))
    model.add(layers.Flatten())


    model.add(layers.Dense(units=512, activation='relu'))    

    age_input = keras.layers.Input(shape=(nucleus_input,), name='nucleus_input') 
    merged = Concatenate()([model.output, age_input])
    merged1= layers.Dense(units=256, activation='relu')(merged)
    
    model_output = layers.Dense(units=output_units, activation='linear')(merged1)

    model = keras.Model(inputs=[model.input, age_input], outputs=model_output)

    return model
