
import numpy as np
import pandas as pd
import seaborn as sns
import scipy.stats as stats
from matplotlib import pyplot as plt
from statsmodels.stats.multitest import multipletests
from sklearn.metrics import median_absolute_error


def plot_loss(history, current_path):
    plt.figure(figsize=(8.5, 8))
    plt.style.use("classic")
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.title('model loss')
    plt.ylabel('mse')
    plt.xlabel('epoch')
    plt.legend(['train', 'val'], loc='upper left')
    plt.savefig(current_path / "mse_validation_loss.png", bbox_inches="tight")
    plt.show()

def plot_log_loss(history, current_path):
    plt.figure(figsize=(8.5, 8))
    plt.style.use("classic")
    plt.plot(np.log(history.history['loss']))
    plt.plot(np.log(history.history['val_loss']))
    plt.title('model loss')
    plt.ylabel('mse')
    plt.xlabel('epoch')
    plt.legend(['train', 'val'], loc='upper left')
    plt.savefig(current_path / "mse_validation_loss-log.png",bbox_inches="tight")
    plt.show()


def aggregate_value(y_pred, test_label, Image_ID):
    
    value_to_indices = {}
    for i, value in enumerate(Image_ID):
        if value not in value_to_indices:
            value_to_indices[value] = [i]
        else:
            value_to_indices[value].append(i)

    # Initialize an empty array to store the grouped data
    grouped_array_label = np.empty((len(value_to_indices), 100))
    grouped_array_pred = np.empty((len(value_to_indices), 100))

    # Calculate means and populate the grouped array
    for i, value in enumerate(value_to_indices.keys()):
        indices = value_to_indices[value]
        grouped_row_label = np.median(test_label[indices], axis=0)
        grouped_row_pred = np.median(y_pred[indices], axis=0)
        grouped_array_label[i] = grouped_row_label
        grouped_array_pred[i] = grouped_row_pred
    
    return grouped_array_pred, grouped_array_label



def calculate_correlation(y_pred_wsi, test_label_wsi):
    corr=[]
    corr_df=pd.DataFrame(np.nan, index=range(100), columns=range(1))
    p_df=pd.DataFrame(np.nan, index=range(100), columns=range(1))
    mae_mean_df = pd.DataFrame(np.nan, index=range(100), columns=range(2))

    for i in range(100):

        j=i
        a=stats.pearsonr(y_pred_wsi[:,j], test_label_wsi[:,i])#spearmanr, axis=0, nan_policy='propagate', alternative='two-sided')  
        a=list(a)
        corr=a[0]
        corr_df.iloc[i,0]=corr
        p=a[1]
        p_df.iloc[i,0]=p

        mae = median_absolute_error(test_label_wsi[:,i], y_pred_wsi[:,i])
        mae_mean_df.iloc[i,0] = mae
        mean = np.mean(test_label_wsi[:,i])
        mae_mean_df.iloc[i,1] = mean

    final_corr005=pd.DataFrame(np.nan, index=range(100), columns=range(1))
    final_corr005["corr_p_005"]=corr_df[p_df<0.05]
    final_corr005["index"]=range(100)
    final_corr005["raw_corr"]=corr_df
    final_corr005["raw_p"]=p_df
    multi=multipletests(np.array(final_corr005["raw_p"]) , alpha=0.05, method='hs', is_sorted=False, returnsorted=False)
    final_mae_mean = pd.DataFrame(np.nan, index=range(100), columns=range(0))
    final_mae_mean["MAE"] = mae_mean_df.iloc[:,0]
    final_mae_mean["Mean"] = mae_mean_df.iloc[:,1]

    final_corr005["multi"]=multi[1]
    final_corr005['corr_multi_005'] = final_corr005['corr_p_005'].where(final_corr005['multi'] < 0.05)
    final_corr005.to_excel("expression_prediction_corr_005_genes.xlsx")
    final_mae_mean.to_excel("expression_prediction_mae_mean_genes.xlsx")

    return final_corr005["corr_multi_005"], multi

def plot_corr_distribution(data, current_path):
    data=data[~np.isnan(data)]
    data=data[data>0]
    fig = plt.figure(figsize =(2, 6))
    plt.style.use("fast")
    plt.boxplot(data)
    plt.ylim(0,1.0)
    plt.tick_params(labelsize=14)
    plt.savefig(current_path / "correlation-distribution.png",bbox_inches="tight")
    plt.show()
    return None



def all_plots(history, y_pred, test_label, Image_ID_test, current_path):

    plot_loss(history, current_path)
    plot_log_loss(history, current_path)


    y_pred_wsi, test_label_wsi=aggregate_value(y_pred, test_label, Image_ID_test)
    data, multi = calculate_correlation(y_pred_wsi, test_label_wsi)
    plot_corr_distribution(data, current_path)

    np.save("y_pred_wsi.npy",y_pred_wsi)
    np.save("test_label_wsi.npy",test_label_wsi)
    
    return (y_pred_wsi,test_label_wsi)
