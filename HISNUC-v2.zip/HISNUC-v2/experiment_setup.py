
import os
import sys
import logging
import datetime
from pathlib import Path


MAIN_DIR = os.getcwd()
EXP_NAME = "tile-NIC-CNN-matrix"

def get_run_folder(args):
    args_str = f"lr{args.learning_rate}-test_size{args.test_size}-batch_size{args.batch_size}-epochs{args.epochs}-rows{args.image_count}"
    now_str = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    return f"run_{now_str}_{args_str}"

def create_path(parent_dir, child_dirs):
    path = parent_dir
    for child_dir in child_dirs:
        path = path / child_dir
        path.mkdir(exist_ok=True)
    return path

def initialize_experiment(args):
    current_path = create_path(Path(MAIN_DIR), ["data", EXP_NAME, get_run_folder(args)])
    return current_path
