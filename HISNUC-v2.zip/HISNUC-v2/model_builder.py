import tensorflow as tf
from tensorflow.keras import layers, Model
from tensorflow import keras
from keras.layers import Dropout
import random
from keras.regularizers import l2
from keras.layers import Concatenate # Add this line
from tensorflow.keras.layers import Input

# Set the seed using keras.utils.set_random_seed. This will set:
# 1) `numpy` seed
# 2) backend random seed
# 3) `python` random seed
keras.utils.set_random_seed(20)

# If using TensorFlow, this will make GPU ops as deterministic as possible,
# but it will affect the overall performance, so be mindful of that.
tf.config.experimental.enable_op_determinism()

# class MaxNetEncoder(Model):#demg
#     def __init__(self, input_dim=9,layer1=24,layer2=8, omic_dim=20, dropout_rate=0):
#         super(MaxNetEncoder, self).__init__()
#         self.input_dim = input_dim
#         self.omic_dim = omic_dim
#         self.dropout_rate = dropout_rate
#         self.encoder = tf.keras.Sequential([
#             layers.Dense(layer1, activation='elu'),
# #            layers.AlphaDropout(rate=dropout_rate),
# #             layers.Dense(layer2, activation='elu'),
# #             layers.AlphaDropout(rate=dropout_rate),
#             layers.Dense(omic_dim, activation='relu')  # Final embedding layer
#         ])

#     def call(self, inputs):
#         return self.encoder(inputs)

#     def get_config(self):
#         return {
#             "input_dim": self.input_dim,
#             "omic_dim": self.omic_dim,
#             "dropout_rate": self.dropout_rate
#         }
    
# class MaxNetEncoder2(Model):#nuc
#     def __init__(self, input_dim=9,layer1=16,layer2=8, omic_dim=12, dropout_rate=0):
#         super(MaxNetEncoder2, self).__init__()
#         self.input_dim = input_dim
#         self.omic_dim = omic_dim
#         self.dropout_rate = dropout_rate
#         self.encoder = tf.keras.Sequential([
#             layers.Dense(layer1, activation='elu'),
# #            layers.AlphaDropout(rate=dropout_rate),
# #             layers.Dense(layer2, activation='elu'),
# #             layers.AlphaDropout(rate=dropout_rate),
#             layers.Dense(omic_dim, activation='relu')  # Final embedding layer
#         ])

#     def call(self, inputs):
#         return self.encoder(inputs)

#     def get_config(self):
#         return {
#             "input_dim": self.input_dim,
#             "omic_dim": self.omic_dim,
#             "dropout_rate": self.dropout_rate
#         }

import tensorflow as tf
from tensorflow.keras import layers, models, initializers
    
def build_selfnorm_encoder(input_dim=25, hidden_dim=22, output_dim=20, dropout_rate=0.05):
    model = models.Sequential([
        layers.Input(shape=(input_dim,)),
        layers.Dense(hidden_dim, activation='selu', kernel_initializer='lecun_normal'),
        layers.AlphaDropout(rate=dropout_rate),
        layers.Dense(output_dim, activation='selu', kernel_initializer='lecun_normal'),
        layers.AlphaDropout(rate=dropout_rate)
    ])
    return model

def build_selfnorm_encoder2(input_dim=20, hidden_dim=16, output_dim=12, dropout_rate=0.05):
    model = models.Sequential([
        layers.Input(shape=(input_dim,)),
        layers.Dense(hidden_dim, activation='selu', kernel_initializer='lecun_normal'),
        layers.AlphaDropout(rate=dropout_rate),
        layers.Dense(output_dim, activation='selu', kernel_initializer='lecun_normal'),
        layers.AlphaDropout(rate=dropout_rate)
    ])
    return model


def build_model(output_units: int, input_shape: tuple, demographic_feature_input_shape: int, nucleus_feature_input_shape: int):
    random.seed(10)
    model = keras.Sequential()

    model.add(layers.Conv2D(filters=64, kernel_size=(3, 3), activation='relu', input_shape=input_shape))
    model.add(layers.AveragePooling2D())
    model.add(layers.Dropout(0.2, seed=20))
    model.add(layers.Conv2D(filters=128, kernel_size=(3, 3), activation='relu'))
    model.add(layers.AveragePooling2D())
    model.add(layers.Dropout(0.2, seed=20))
    model.add(layers.Conv2D(filters=256, kernel_size=(3, 3), activation='relu'))
    model.add(layers.AveragePooling2D())
    model.add(layers.Dropout(0.2, seed=20))
    model.add(layers.Flatten())

    #  for 100/50
    #model.add(layers.Dense(units=4096, activation='relu'))
    model.add(layers.Dense(units=512, activation='relu'))
    model.add(layers.Dense(units=256, activation='relu'))
    model.add(layers.Dense(units=64, activation='relu'))

    # Input for nucleus features
    demg_input = layers.Input(shape=(demographic_feature_input_shape,), name='demg_input')
    nuc_input = layers.Input(shape=(nucleus_feature_input_shape,), name='nucleus_input')
    
    # Pass nucleus features through MaxNetEncoder
    maxnet_encoder = build_selfnorm_encoder(input_dim=demographic_feature_input_shape)
    encoded_nucleus = maxnet_encoder(demg_input)

    
    maxnet_encoder2= build_selfnorm_encoder2(input_dim=nucleus_feature_input_shape)#, layer1=16, layer2=8,  omic_dim=4)
    encoded_nucleus2 = maxnet_encoder2(nuc_input)
    
    pooled_features_with_1 = tf.concat([model.output, tf.ones_like(model.output[:, :1])], axis=-1)
    encoded_nucleus_with_1 = tf.concat([encoded_nucleus, tf.ones_like(encoded_nucleus[:, :1])], axis=-1)
    encoded_nucleus2_with_1 = tf.concat([encoded_nucleus2, tf.ones_like(encoded_nucleus2[:, :1])], axis=-1)

    # Reshape for broadcasting
    pf_exp = tf.expand_dims(tf.expand_dims(pooled_features_with_1, axis=2), axis=3)  # (batch_size, 64, 1, 1)
    en_exp = tf.expand_dims(tf.expand_dims(encoded_nucleus_with_1, axis=1), axis=3)  # (batch_size, 1, 6, 1)
    en2_exp = tf.expand_dims(tf.expand_dims(encoded_nucleus2_with_1, axis=1), axis=2) # (batch_size, 1, 1, 6)
    
    # Compute outer product
    outer_product = pf_exp * en_exp * en2_exp  # (batch_size, 64, 6, 6)
    
    # Flatten the tensor
    # flattened = tf.reshape(outer_product, shape=(tf.shape(outer_product)[0], -1))  # (batch_size, 2304)
    flattened = tf.reshape(outer_product, shape=(-1, 65 * 21 * 13))  # Ensure correct shape
    merged = flattened
    
#     outer_tensor = pf_exp * demog_exp * nucleus_exp
#     outer_flat = tf.reshape(outer_tensor, shape=(-1, 65 * 13 * 21))



#     # Final prediction layers
#     dense_output = layers.Dense(128, activation='relu')(outer_flat)
#     final_output = layers.Dense(output_units, activation='linear')(dense_output)


    # Combine patch-level features and encoded nucleus features
    # Old way: merged = layers.Concatenate()([pooled_features, age_input])
    #merged = layers.Concatenate()([model.output, encoded_nucleus, encoded_nucleus2])
    
    # Fully connected layers after merging
    merged1 = layers.Dense(units=512, activation='relu')(merged)
    
    model_output = layers.Dense(units=output_units, activation='linear')(merged1)

    model = keras.Model(inputs=[model.input, demg_input, nuc_input], outputs=model_output)

    return model
