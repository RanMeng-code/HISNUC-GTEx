
import numpy as np
import pandas as pd
import seaborn as sns
import scipy.stats as stats
from matplotlib import pyplot as plt
from statsmodels.stats.multitest import multipletests
from sklearn.metrics import median_absolute_error
from sklearn.metrics import mean_squared_error, mean_absolute_error, median_absolute_error



def plot_loss(history, current_path):
    plt.figure(figsize=(8.5, 8))
    plt.style.use("classic")
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.title('model loss')
    plt.ylabel('mse')
    plt.xlabel('epoch')
    plt.legend(['train', 'val'], loc='upper left')
    plt.savefig(current_path / "mse_validation_loss.png", bbox_inches="tight")
    plt.show()

def plot_log_loss(history, current_path):
    plt.figure(figsize=(8.5, 8))
    plt.style.use("classic")
    plt.plot(np.log(history.history['loss']))
    plt.plot(np.log(history.history['val_loss']))
    plt.title('model loss')
    plt.ylabel('mse')
    plt.xlabel('epoch')
    plt.legend(['train', 'val'], loc='upper left')
    plt.savefig(current_path / "mse_validation_loss-log.png",bbox_inches="tight")
    plt.show()


# def aggregate_value(y_pred, test_label, Image_ID):

#     return y_pred, test_label
def aggregate_value(y_pred, test_label, Image_ID,current_path):
    
    value_to_indices = {}
    for i, value in enumerate(Image_ID):
        if value not in value_to_indices:
            value_to_indices[value] = [i]
        else:
            value_to_indices[value].append(i)

    # Initialize an empty array to store the grouped data
    grouped_array_label = np.empty((len(value_to_indices), 100))
    grouped_array_pred = np.empty((len(value_to_indices), 100))

    # Calculate means and populate the grouped array
    for i, value in enumerate(value_to_indices.keys()):
        indices = value_to_indices[value]
        grouped_row_label = np.median(test_label[indices], axis=0)
        grouped_row_pred = np.median(y_pred[indices], axis=0)
        grouped_array_label[i] = grouped_row_label
        grouped_array_pred[i] = grouped_row_pred
    
    return grouped_array_pred, grouped_array_label


def calculate_correlation(y_pred_wsi, test_label_wsi):
    import numpy as np
    import pandas as pd
    from scipy import stats
    from sklearn.metrics import mean_squared_error, mean_absolute_error, median_absolute_error
    from statsmodels.stats.multitest import multipletests

    # Preallocate
    corr_log_df = pd.DataFrame(np.nan, index=range(100), columns=["corr"])
    p_log_df = pd.DataFrame(np.nan, index=range(100), columns=["p"])
    corr_raw_df = pd.DataFrame(np.nan, index=range(100), columns=["corr_raw"])
    p_raw_df = pd.DataFrame(np.nan, index=range(100), columns=["p_raw"])
    mae_mean_df = pd.DataFrame(np.nan, index=range(100), columns=["MSE_log", "MAE_log", "MEAN_log", "Med_AE_log", "Median_log"])
    mae_mean_df_raw = pd.DataFrame(np.nan, index=range(100), columns=["MSE_raw", "MAE_raw", "MEAN_raw", "Med_AE_raw", "Median_raw"])

    for i in range(100):
        # --- Log-space metrics ---
        corr, p = stats.pearsonr(y_pred_wsi[:, i], test_label_wsi[:, i])
        corr_log_df.iloc[i, 0] = corr
        p_log_df.iloc[i, 0] = p

        mse = mean_squared_error(test_label_wsi[:, i], y_pred_wsi[:, i])
        mae = mean_absolute_error(test_label_wsi[:, i], y_pred_wsi[:, i])
        mean = np.mean(test_label_wsi[:, i])
        med_ae = median_absolute_error(test_label_wsi[:, i], y_pred_wsi[:, i])
        median = np.median(test_label_wsi[:, i])
        mae_mean_df.iloc[i] = [mse, mae, mean, med_ae, median]

        # --- Raw TPM space ---
        y_true_raw = np.exp(test_label_wsi[:, i]) - 1
        y_pred_raw = np.exp(y_pred_wsi[:, i]) - 1

        corr_raw, p_raw = stats.pearsonr(y_pred_raw, y_true_raw)
        corr_raw_df.iloc[i, 0] = corr_raw
        p_raw_df.iloc[i, 0] = p_raw

        mse_raw = mean_squared_error(y_true_raw, y_pred_raw)
        mae_raw = mean_absolute_error(y_true_raw, y_pred_raw)
        mean_raw = np.mean(y_true_raw)
        med_ae_raw = median_absolute_error(y_true_raw, y_pred_raw)
        median_raw = np.median(y_true_raw)
        mae_mean_df_raw.iloc[i] = [mse_raw, mae_raw, mean_raw, med_ae_raw, median_raw]

    # === Multiple testing correction ===
    # Log space correction
    raw_p_log = p_log_df["p"].values
    raw_corr_log = corr_log_df["corr"].values
    fdr_log = multipletests(raw_p_log, alpha=0.05, method='hs')[1]

    # Raw space correction
    raw_p_raw = p_raw_df["p_raw"].values
    raw_corr_raw = corr_raw_df["corr_raw"].values
    fdr_raw = multipletests(raw_p_raw, alpha=0.05, method='hs')[1]

    # === Assemble final correlation DataFrame ===
    final_corr_df = pd.DataFrame({
        "log_corr": raw_corr_log,
        "log_p": raw_p_log,
        "log_FDR_p": fdr_log,
        "log_corr_FDR_005": np.where(fdr_log < 0.05, raw_corr_log, np.nan),
        "raw_corr": raw_corr_raw,
        "raw_p": raw_p_raw,
        "raw_FDR_p": fdr_raw,
        "raw_corr_FDR_005": np.where(fdr_raw < 0.05, raw_corr_raw, np.nan)
    })

    # === Save log-space and raw-space metrics ===
    final_mae_mean = mae_mean_df.copy()
    final_mae_mean_raw = mae_mean_df_raw.copy()

    with pd.ExcelWriter("expression_prediction_metrics.xlsx") as writer:
        final_corr_df.to_excel(writer, sheet_name="Correlation_Log_and_Raw")
        final_mae_mean.to_excel(writer, sheet_name="Log_Space_Metrics")
        final_mae_mean_raw.to_excel(writer, sheet_name="Raw_TPM_Metrics")

    return final_corr_df["log_corr_FDR_005"], final_corr_df["raw_corr_FDR_005"]


def plot_corr_distribution(data, current_path):
    data=data[~np.isnan(data)]
    data=data[data>0]
    fig = plt.figure(figsize =(2, 6))
    plt.style.use("fast")
    plt.boxplot(data)
    plt.ylim(0,1.0)
    plt.tick_params(labelsize=14)
    plt.savefig(current_path / "correlation-distribution.png",bbox_inches="tight")
    plt.show()
    return None



def all_plots(history, y_pred, test_label, Image_ID_test, current_path):

    plot_loss(history, current_path)
    plot_log_loss(history, current_path)


    y_pred_wsi, test_label_wsi=aggregate_value(y_pred, test_label, Image_ID_test,current_path)
    data, multi = calculate_correlation(y_pred_wsi, test_label_wsi)
    plot_corr_distribution(data, current_path)

    np.save("y_pred_wsi.npy",y_pred_wsi)
    np.save("test_label_wsi.npy",test_label_wsi)
    
    return (y_pred_wsi,test_label_wsi)
