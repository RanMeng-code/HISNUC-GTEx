
import os
import random
import numpy as np
import pandas as pd
from augumentation import selection
from logger_config import logger

def is_valid_patch(patch):
    return patch.shape == (32, 32, 128) and np.isnan(patch[:, :, 1]).sum() < 450

def augment_patch(patch, nucleus_label, gene_expression, patches, nucleus_labels, gene_expressions, image_id, image_ids, occupancy, is_train_data):
    if is_valid_patch(patch):
        patch_normalized = np.nan_to_num(patch)
        patches.append(patch_normalized)
        nucleus_labels.append(nucleus_label)
        gene_expressions.append(gene_expression)
        image_ids.append(image_id)
        occupancy.append(np.isnan(patch[:, :, 1]).sum() / (32 * 32))

def process_slide(image_id, nucleus_label, gene_expression, patches, nucleus_labels, gene_expressions, image_ids, occupancy, is_train_data):
    features = np.load(image_id + "_features.npy")
    features_transposed = np.swapaxes(features, 0, 2)
    valid_features = []

    for channel in range(128):
        channel_data = features_transposed[:, :, channel]
        valid_rows = channel_data[~np.isnan(channel_data).all(axis=1)]
        valid_cols = valid_rows.T[~np.isnan(valid_rows.T).all(axis=1)].T
        valid_features.append(valid_cols)

    valid_features_array = np.array(valid_features)
    valid_features_transposed = np.swapaxes(valid_features_array, 0, 2)

    features_height = valid_features_transposed.shape[0]
    features_width = valid_features_transposed.shape[1]
    height_steps = features_height // 16
    width_steps = features_width // 16

    for i in range(height_steps - 2):
        for j in range(width_steps - 2):
            patch = valid_features_transposed[i * 16 : i * 16 + 32, j * 16 : j * 16 + 32, :]
            augment_patch(patch, nucleus_label, gene_expression, patches, nucleus_labels, gene_expressions, image_id, image_ids, occupancy, is_train_data)

        patch = valid_features_transposed[i * 16 : i * 16 + 32, -33:-1, :]
        augment_patch(patch, nucleus_label, gene_expression, patches, nucleus_labels, gene_expressions, image_id, image_ids, occupancy, is_train_data)

    for j in range(width_steps - 2):
        patch = valid_features_transposed[-33:-1, j * 16 : j * 16 + 32, :]
        augment_patch(patch, nucleus_label, gene_expression, patches, nucleus_labels, gene_expressions, image_id, image_ids, occupancy, is_train_data)

    patch = valid_features_transposed[-33:-1, -33:-1, :]
    augment_patch(patch, nucleus_label, gene_expression, patches, nucleus_labels, gene_expressions, image_id, image_ids, occupancy, is_train_data)


def process_all_slides(data, nucleus_data, gene_expression_data, is_train_data, IMG_DIR):
    patches = []
    nucleus_labels = []
    gene_expressions = []
    image_ids = []
    occupancy = []

    os.chdir(IMG_DIR)
    if is_train_data:
        logger.info("Processing all slides: training")
    else:
        logger.info("Processing all slides: testing")

    for _, row in data.iterrows():
        image_file = row['image_file']
        nucleus_label = nucleus_data.loc[row.name]
        gene_expression = gene_expression_data.loc[row.name]
        process_slide(image_file, nucleus_label, gene_expression, patches, nucleus_labels, gene_expressions, image_ids, occupancy, is_train_data)

    logger.info("Finished processing.")
    return patches, nucleus_labels, gene_expressions, image_ids, occupancy

# def process_all_slides(data, nucleus_data, gene_expression_data, is_train_data, IMG_DIR):   ## data, nucleus, labels, is_train_data, IMG_DIR
#     patches = []
#     nucleus_labels = []
#     gene_expressions = []
#     image_ids = []
#     occupancy = []

#     os.chdir(IMG_DIR)
#     if is_train_data:
#         logger.info("Processing all slides: training")
#     else:
#         logger.info("Processing all slides: testing")

#     for index, i in enumerate(data.iterrows()):
#         image_file = data.iloc[index]['image_file']
#         nucleus_label= nucleus.iloc[index]
#         y_label = labels.iloc[index] # access label using integer index
#         process_slide(image_file, nucleus_label, gene_expression, patches, nucleus_labels, gene_expressions, image_ids, occupancy, is_train_data)

#     logger.info("Finished processing.")
#     return patches, nucleus_labels, gene_expressions, image_ids, occupancy

def stack_data(patches, nucleus_labels, gene_expressions, image_ids, occupancy):
    logger.info("Stacking data...")

    images = np.stack(patches)
    nucleus_data = np.stack(nucleus_labels)
    gene_expression_data = np.array(gene_expressions)
    occupancy_data = np.array(occupancy)
    image_ids_data = np.array(image_ids)

    logger.info(f"Images shape: {images.shape}")
    logger.info(f"Nucleus data shape: {nucleus_data.shape}")
    logger.info(f"Gene expression data shape: {gene_expression_data.shape}")
    logger.info(f"Occupancy data shape: {occupancy_data.shape}")
    logger.info(f"Image IDs shape: {image_ids_data.shape}")

    image_dict = {i: images[i] for i in range(len(image_ids_data))}
    nucleus_dict = {i: nucleus_data[i] for i in range(len(image_ids_data))}

    image_df = pd.DataFrame({"Image_ID": image_ids_data, "Occupancy": occupancy_data})

    gene_expression_df = pd.DataFrame(gene_expression_data, columns=list(range(2, 102)))

    # concatenate the image df and gene expression df along the column axis
    image_df = pd.concat([image_df, gene_expression_df], axis=1)

    logger.info(f"Image DataFrame shape: {image_df.shape}")

    image_df.sort_values(by=["Image_ID", "Occupancy"], ascending=[True, False], inplace=True)

    logger.info("Selecting top images...")

    # group by Image_ID and keep top 8 images
    top_images = image_df.groupby("Image_ID").head(8)

    logger.info(f"Top images shape: {top_images.shape}")

    selected_images = [image_dict[key] for key in top_images.index]
    selected_nucleus = [nucleus_dict[key] for key in top_images.index]
    stacked_images = np.stack(selected_images)
    stacked_nucleus = np.stack(selected_nucleus)

    logger.info(f"Stacked images shape: {stacked_images.shape}")
    logger.info(f"Stacked nucleus shape: {stacked_nucleus.shape}")

    selected_gene_expressions = np.array(top_images[list(range(2, 102))])
    selected_image_ids = top_images["Image_ID"]
    selected_occupancy = np.array(top_images["Occupancy"])

    logger.info(f"Selected gene expressions shape: {selected_gene_expressions.shape}")
    logger.info(f"Selected image IDs shape: {selected_image_ids.shape}")
    logger.info(f"Selected occupancy shape: {selected_occupancy.shape}")

    return stacked_images, stacked_nucleus, selected_gene_expressions, selected_image_ids, selected_occupancy
