
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import argparse
import numpy as np
import tensorflow as tf
from matplotlib import pyplot as plt
from tensorflow.keras import optimizers, losses, layers
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
from logger_config import setup_logger, logger
import experiment_setup
import data_setup, processingslide
import model_builder, save_models, plots

parser = argparse.ArgumentParser(description='Training script')
parser.add_argument('--target_genes', type=int, default=100)
parser.add_argument('--seed', type=int, default=20)
parser.add_argument('--test_size', type=float, default=0.33)
parser.add_argument('--image_count', type=int, default=100)
parser.add_argument('--learning_rate', type=float, default=0.00004)
parser.add_argument('--batch_size', type=int, default=10)
parser.add_argument('--epochs', type=int, default=5)
parser.add_argument('--csv_file',type=str, default='/gpfs/gibbs/pi/gerstein/rm2586/GTEx-imaging-prediction/Thyroid-expression-prediction/Thyroid-gene-log-sorted-by-var_without_mean.csv')
parser.add_argument('--image_dir', type=str, default='/gpfs/gibbs/pi/gerstein/rm2586/GTEx-imaging-prediction/Thyroid-expression-prediction/Thyroid-no-bounding-features-remove-bg')
parser.add_argument('--qupath_feature_path', type=str, default="/gpfs/gibbs/pi/gerstein/tu54/imaging_project/imaging-QTL/imaging-QTL-Thyroid-rm/qupath-feature-kde-IQR-Q1Q3.csv")
parser.add_argument('--metadata_file', type=str, default="/gpfs/gibbs/pi/gerstein/rm2586/GTEx-imaging-prediction/GTEx-meta-032724.csv")
parser.add_argument('--tissue_name', type=str, default="Thyroid")
parser.add_argument('--tau_threshold', type=float, default=0.85)
parser.add_argument('--expression_threshold', type=float, default=0)

args = parser.parse_args()

# if args.image_count > 800:
#     logger.info("Error: image_count cannot be more than 800")
#     exit()

current_path = experiment_setup.initialize_experiment(args)
setup_logger(current_path)
logger.info(tf.__version__)
logger.info(tf.config.list_physical_devices('GPU'))
logger.info('Experiment setup complete.\n')

train_data, nucleus_train, train_tag, val_data, nucleus_val, val_tag, test_data, nucleus_test, test_tag= data_setup.create_datasets(
    args.csv_file,
    args.image_dir,
    args.qupath_feature_path,
    args.metadata_file,
    args.tissue_name,
    args.tau_threshold,
    args.expression_threshold,
    args.target_genes, 
    args.seed,
    args.test_size
)

logger.info("###### whole_sample_size #####")
logger.info(nucleus_train.shape)
logger.info(nucleus_val.shape)
logger.info(nucleus_test.shape)

logger.info("Processing all slides: training 32*32, smaller than 450, top4, without amplification, shift 32, decay_steps=10000, decay_rate=0.95")

sum_x_train, sum_nucleus_train, sum_y_train, Image_ID_train, occup_train = processingslide.process_all_slides(train_data, nucleus_train, train_tag, True, args.image_dir)
sum_x_val, sum_nucleus_val, sum_y_val, Image_ID_val, occup_val = processingslide.process_all_slides(val_data, nucleus_val, val_tag, False, args.image_dir)
sum_x_test, sum_nucleus_test, sum_y_test, Image_ID_test, occup_test = processingslide.process_all_slides(test_data, nucleus_test, test_tag, False, args.image_dir)

logger.info("###### processing_slide ######")
train_image, train_nucleus, train_labels, Image_ID_train_final, occup_train_final = processingslide.stack_data(sum_x_train, sum_nucleus_train, sum_y_train, Image_ID_train, occup_train)
val_image, val_nucleus, val_labels, Image_ID_val_final, occup_val_final= processingslide.stack_data(sum_x_val, sum_nucleus_val, sum_y_val, Image_ID_val, occup_val)
test_image, test_nucleus, test_labels, Image_ID_test_final, occup_test_final = processingslide.stack_data(sum_x_test, sum_nucleus_test, sum_y_test, Image_ID_test, occup_test)

logger.info("\n###### sample_size ######")
logger.info(train_image.shape)
logger.info(train_nucleus.shape)
logger.info(test_image.shape)

logger.info("\n###### whole_sample_size_inuse_before_stacking ######")
logger.info(len(set(Image_ID_train)))
logger.info(len(set(Image_ID_val)))
logger.info(len(set(Image_ID_test)))

logger.info("\n###### whole_sample_size_inuse_after_stacking #####")
logger.info(len(set(Image_ID_train_final)))
logger.info(len(set(Image_ID_val_final)))
logger.info(len(set(Image_ID_test_final)))

logger.info(f"\ntrain_image_shape: {train_image.shape}")
input_shape = train_image.shape[1:]
output_units = train_labels.shape[1]

nucleus_input = train_nucleus.shape[1]
logger.info(f"\nnucleus_input: {nucleus_input}")

demographic_feature_input_shape=25
nucleus_feature_input_shape=nucleus_input-demographic_feature_input_shape
model = model_builder.build_model(output_units, input_shape, demographic_feature_input_shape, nucleus_feature_input_shape)
logger.info("model summary")
logger.info(model.summary())
os.chdir(current_path)


lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
    args.learning_rate,
    decay_steps=10000,
    decay_rate=0.95,
    staircase=True)

callbacks = [
    ModelCheckpoint(
        filepath="noise_mnist.keras",
        save_best_only=True,
        monitor="val_loss"),
    EarlyStopping(monitor='val_loss', patience=30)
]
opt = tf.keras.optimizers.SGD(learning_rate=lr_schedule)
model.compile(optimizer=opt, loss="mse")

train_demographic=train_nucleus[:,0:25]
val_demographic=val_nucleus[:,0:25]
test_demographic=test_nucleus[:,0:25]
train_nucleus_only=train_nucleus[:,25:]
val_nucleus_only=val_nucleus[:,25:]
test_nucleus_only=test_nucleus[:,25:]


# history = model.fit([train_image, train_nucleus], train_labels, epochs=args.epochs, batch_size=args.batch_size, validation_data=([val_image,val_nucleus], val_labels), callbacks=callbacks)
# y_pred = model.predict([test_image,test_nucleus])
# results = model.evaluate([test_image,test_nucleus], test_labels)

history = model.fit([train_image, train_demographic, train_nucleus_only], train_labels, epochs=args.epochs, batch_size=args.batch_size, validation_data=([val_image,val_demographic,val_nucleus_only], val_labels), callbacks=callbacks)
y_pred = model.predict([test_image, test_demographic, test_nucleus_only])
results = model.evaluate([test_image, test_demographic, test_nucleus_only], test_labels)

save_models.save_model(model=model,
           history=history,
           current_path=current_path,
           target_dir="models",
           model_name="basic.h5",
           y_pred=y_pred,
           test_label=test_labels)

logger.info("Making plots")
plots.all_plots(history, y_pred, test_labels, Image_ID_test_final, current_path)
logger.info("Done.")
